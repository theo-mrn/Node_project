import { Request, Response } from 'express';
import { Movie } from '../models/movie';

export const getMovies = async (req: Request, res: Response): Promise<void> => {
  try {
    const movies = await Movie.findAll();
    res.json(movies);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
};

export const getMovieById = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const movie = await Movie.findByPk(id);
    if (!movie) {
      res.status(404).json({ error: 'Movie not found' });
      return;
    }
    res.json(movie);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
};

export const createMovie = async (req: Request, res: Response): Promise<void> => {
  try {
    const newMovie = await Movie.create(req.body);
    res.status(201).json(newMovie);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
};

export const updateMovie = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const [updated] = await Movie.update(req.body, { where: { id } });
    if (!updated) {
      res.status(404).json({ error: 'Movie not found' });
      return;
    }
    const updatedMovie = await Movie.findByPk(id);
    res.json(updatedMovie);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
};

export const deleteMovie = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const deleted = await Movie.destroy({ where: { id } });
    if (!deleted) {
      res.status(404).json({ error: 'Movie not found' });
      return;
    }
    res.json({ message: 'Movie deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
};
