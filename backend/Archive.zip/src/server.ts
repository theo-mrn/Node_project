import express, { Application } from 'express';
import swaggerUi from 'swagger-ui-express';
import bodyParser from 'body-parser';
import cors from 'cors'; // Assurez-vous que le module est bien installé
import { sequelize } from './config/database';
import movieRoutes from './routes/movieRoutes';
import swaggerDocument from './swagger/swagger.json';
import userRoutes from './routes/userRoutes';

const app: Application = express();
const PORT = 3000;

// Test de la connexion à la base de données
sequelize.authenticate()
  .then(() => console.log('Connected to PostgreSQL'))
  .catch((err: Error) => console.error('Unable to connect to the database:', err));

// Synchronisation des tables (optionnel : force à false pour ne pas recréer les tables à chaque démarrage)
sequelize.sync({ force: true })
  .then(() => console.log('Database synced'))
  .catch((err: Error) => console.error('Error syncing database:', err));

// Middleware CORS
app.use(
  cors({
    origin: 'http://localhost:4200', // Autoriser Angular (remplacez par votre URL en production)
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true,
  })
);

// Middleware
app.use(bodyParser.json());
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument)); // Swagger UI
app.use('/movies', movieRoutes); // Routes pour les films
app.use('/users', userRoutes);   // Routes pour les utilisateurs

// Démarrage du serveur
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
