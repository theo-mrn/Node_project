import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

// Middleware pour authentifier les requêtes avec JWT
export const authenticateToken = (req: Request, res: Response, next: NextFunction): void => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Récupérer le token depuis le header Authorization

  if (!token) {
    res.status(401).json({ error: 'Access token missing or invalid' });
    return;
  }

  try {
    const decoded = jwt.verify(token, 'your-secret-key'); // Remplacez par votre clé secrète
    (req as any).user = decoded; // Ajouter les données décodées au req pour les utiliser dans vos routes
    next();
  } catch (err) {
    res.status(403).json({ error: 'Invalid or expired token' });
  }
};
