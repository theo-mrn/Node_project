import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database';

export const Movie = sequelize.define('Movie', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  poster_link: { type: DataTypes.TEXT },
  series_title: { type: DataTypes.STRING, allowNull: false },
  released_year: { type: DataTypes.INTEGER },
  certificate: { type: DataTypes.STRING },
  runtime: { type: DataTypes.STRING },
  genre: { type: DataTypes.STRING },
  imdb_rating: { type: DataTypes.FLOAT },
  overview: { type: DataTypes.TEXT },
  meta_score: { type: DataTypes.INTEGER },
  director: { type: DataTypes.STRING },
  star1: { type: DataTypes.STRING },
  star2: { type: DataTypes.STRING },
  star3: { type: DataTypes.STRING },
  star4: { type: DataTypes.STRING },
  no_of_votes: { type: DataTypes.INTEGER },
  gross: { type: DataTypes.BIGINT },
}, {
  tableName: 'movies',
  timestamps: false, // Désactive createdAt et updatedAt
});
