import { Model, DataTypes, Optional } from 'sequelize';
import { sequelize } from '../config/database';

// Définir les attributs du modèle User
interface UserAttributes {
  id: number;
  username: string;
  email: string;
  password: string;
}

// Définir les attributs optionnels pour la création d'un utilisateur
interface UserCreationAttributes extends Optional<UserAttributes, 'id'> {}

// Définir le modèle User
export class User extends Model<UserAttributes, UserCreationAttributes> implements UserAttributes {
  public id!: number;
  public username!: string;
  public email!: string;
  public password!: string;

  // Timestamps
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;
}

// Initialisation du modèle
User.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    username: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    sequelize,
    tableName: 'users',
  }
);

export default User;
