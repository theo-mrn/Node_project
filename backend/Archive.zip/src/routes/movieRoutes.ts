import express from 'express';
import { authenticateToken } from '../middleware/authMiddleware';
import { getMovies, getMovieById, createMovie, updateMovie, deleteMovie } from '../controllers/movieController';

const router = express.Router();

// Routes sécurisées avec le middleware d'authentification
router.get('/', authenticateToken, getMovies);
router.get('/:id', authenticateToken, getMovieById);
router.post('/', authenticateToken, createMovie);
router.put('/:id', authenticateToken, updateMovie);
router.delete('/:id', authenticateToken, deleteMovie);

export default router;
